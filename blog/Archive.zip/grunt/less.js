module.exports = {
    files: {
        expand: true,
        cwd:    'styles/',
        src:    ['main.less'],
        dest:   'compiled/css',
        ext:    '.css'
    }
}