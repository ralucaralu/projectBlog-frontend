//RequireJS config
require.config({paths:{"main":"compiled"},});require(["main"]);